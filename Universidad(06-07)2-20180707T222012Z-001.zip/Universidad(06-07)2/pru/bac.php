<?php 
require_once("../../cone/claseMysql-V10.php");

class MaestroUsuario extends conectarBD
{
	public $cantRegistros = 0;
	public $cantRegistrosHabilidades = 1;
	/**
	 * [__construct se encarga de inicializar el id del usuario]
	 */
	function __construct()
	{
		$this->cantRegistros = 0;
		$this->cantRegistrosHabilidades = 1;
		//$this->id_user = $_SESSION["id_user"];
	}
	/**
	 * [crearusumrtamento description]
	 * @return [type] [description]
	 */
	//mostrar Fornulario
	public function mostrarFornulario(){
		$this->id_user = 1;//$_SESSION["usum_idxx"];
		$sqlusumMaes = $this->consultar("usua_maes","","usum_esta='ACT'");
		if ($sqlusumMaes == 0) {
			$this->formulario();
		}
		else{
			$this->paginarRegistros();
			$this->mostrarRegistros(1);
		}
	}
	
	public function guar_modi_usua(){
		extract($_POST);
		if ($usum_pass=="") {
			$pass="";
		}
		else{
			$pass = ",usum_cont ='".md5($usum_pass)."'";
		}
		$sqlusuarios = $this->consultar("usua_maes","","usum_nomb='$usum_nomb' AND usum_idxx!='$usum_idxx'",1);
		$this->actualizar("usua_maes","usum_iden='".$usum_iden."',usum_nomb='".strtoupper($usum_nomb)."',usum_apel='".strtoupper($usum_apel)."', usum_dire ='".strtoupper($usum_dire)."',usum_tele='".$usum_tele."', usum_movi='".$usum_movi."', usum_emai='".strtolower($usum_emai)."', usum_prof='".strtoupper($usum_prof)."'".$pass.",usum_foto='".$usum_foto_vali."',usum_idpe =".$usum_idpe,"usum_idxx='$usum_idxx'");
		return $usum_idxx;
	}
	
	public function formulario($donde ="nuevo",$usum_idxx=0,$usum_iden="",$usum_nomb="",$usum_apel="",$usum_dire="",$usum_tele="",$usum_movi="",$usum_emai="",$usum_idpe="",$usum_foto="N",$usum_prof=""){
	echo '
		<script type="text/javascript">
			var loadFile = function(event){
				var output = document.getElementById("usum_foto");
				output.src = URL.createObjectURL(event.target.files[0]);
			};
		</script> 
		<form  action="../func/php/FUUSUA_MAES-V10.php" name="formulari" id="formulari" method="post" enctype="multipart/form-data" onSubmit="return guardarUsuario()" autocomplete="off" >
			';
			if ($usum_foto=="S") {
				echo '<img src="../imag/empleados/'.$usum_idxx.'.jpg" id="usum_foto"/>';
			}
			else{
				echo '<img src="../imag/icons/PNG 256x256/Usertemp.png" id="usum_foto"/>';
			}
			echo '
			<input type="hidden"  name="usum_foto_vali" id="usum_foto_vali" value="N">
			<input type="hidden"  name="accion" id="accion" value="guardar_foto">
			<input type="hidden" name="usum_idxx" id="usum_idxx" value="'.$usum_idxx.'">
			<input type="hidden" name="donde" id="donde" value="'.$donde.'">
				<table align="center"  >
					<tr>
						<td><input type="file" name="file" onchange="loadFile(event)" id="file" /></td>
					</tr>
					<tr>
						<td><input type="hidden" name="description" id="description" /></td>
						<td></td>
					</tr>
			</table>
			<div style="overflow-x:auto;""> 
			<table class="tabla_usua">
				<tr id="nombres">
					<td><label for="usr">Cédula:</label></td>
					<td>&nbsp;</td>
					<td><label for="usr">Nombres:</label></td>
					<td>&nbsp;</td>
					<td><label for="usr">Apellidos:</label></td>
				</tr>';
				if ($usum_iden!="") {
					$usum_iden = number_format($usum_iden);
				}
				echo'<tr id="campos">
					<td><input type="text" name="usum_iden" id="usum_iden" maxlength="13" size="25"  class="form-control" size="12" onkeypress="return solonumeros(event);" onblur="verificar_cedula('.$usum_idxx.')" onkeyup = "formatoNumerico(this)" value='.$usum_iden. '></td>    
					<td>&nbsp;</td>
					<td><input type="text" name="usum_nomb" id="usum_nomb" onkeypress="return caracteresEspeciales(event)" maxlength="49" class="form-control" value="'.$usum_nomb.'"  size="45"></td>
					<td>&nbsp;</td>
					<td><input type="text" name="usum_apel" id="usum_apel" onkeypress="return caracteresEspeciales(event)" class="form-control" size="45" value="'.$usum_apel.'" ></td>
				</tr>
			</table>
			<table class="tabla_usua">
				<tr  id="nombres">
					<td><label for="usr">Dirección:</label></td><td>&nbsp;</td>
					<td><label for="usr">Teléfono:</label></td><td>&nbsp;</td>
					<td><label for="usr">Celular:</label></td><td>&nbsp;</td>
					<td><label for="usr">Correo:</label></td>
				</tr>
				<tr id="campos">
					<td width="30%"><input type="text" name="usum_dire" id="usum_dire" onkeypress="return caracteresEspeciales(event)" class="form-control" value="'.$usum_dire.'"></td><td>&nbsp;</td>
					<td><input type="text"  name="usum_tele" id="usum_tele" class="form-control" value="'.$usum_tele.'" size="4" 	onkeypress="return solonumeros(    event);" maxlength="7"></td><td>&nbsp;</td>
					<td><input type="text" name="usum_movi" id="usum_movi" class="form-control" value="'.$usum_movi.'" size="7" onkeypress="return solonumeros(    event);" maxlength="10"></td><td>&nbsp;</td>
					<td><input type="text" name="usum_emai" id="usum_emai" onkeypress="return caracteresEspeciales(event)" class="form-control"  value="'.$usum_emai.'" ></td>
				</tr>
				<tr>
					<table class="tabla_usua">
						<tr  id="nombres">
							<td><label for="usr">Profesion:</label></td><td>&nbsp;</td>
							<td><label for="usr">Contraseña:</label></td><td>&nbsp;</td>
							<td><label for="usr">Repetir Contraseña:</label></td><td>&nbsp;</td>
							<td><label for="usr">Perfil Usuario:</label></td>
						</tr>
						<tr id="campos">
							<td><input class="form-control" type="text" name="usum_prof" id="usum_prof" value="'.$usum_prof.'"></td><td></td>
							<td><div style="display:none"><input type="password" name="usum_pass88" autocomplete="off" id="usum_pass88" onkeypress="return caracteresEspeciales(event)" class="form-control" value="" size="16"></div><input type="password" name="usum_pass" autocomplete="off" id="usum_pass" onkeypress="return caracteresEspeciales(event)" class="form-control" value="" size="16"></td>
							<td>&nbsp;</td>
							<td><input type="password"  name="usum_pas2" id="usum_pas2" onkeypress="return caracteresEspeciales(event)" class="form-control" ></td><td>&nbsp;</td>
							<td><select class="select" name="usum_idpe" id="usum_idpe"><option value="1">Seleccione</option>';
							$sqlPerfMaes = $this->consultar("perf_maes","","perm_esta='ACT'", 1);
							if (mysql_num_rows($sqlPerfMaes)>0) {
								mysql_data_seek($sqlPerfMaes,0);
								while($datosPerfMaes = mysql_fetch_array($sqlPerfMaes)) {
									if ($donde== "modificar") {
										echo ($usum_idpe == $datosPerfMaes['perm_idxx']) ? "<option selected value='".$datosPerfMaes["perm_idxx"]."'>".$datosPerfMaes["perm_nomb"]."</option>" : "<option value='".$datosPerfMaes["perm_idxx"]."'>".$datosPerfMaes["perm_nomb"]."</option>";
									}
									else{
										echo  "<option value='".$datosPerfMaes["perm_idxx"]."'>".$datosPerfMaes["perm_nomb"]."</option>";
									}
								}
							}
						echo'
							</select><input type="hidden" name="usum_idpe_hidden" id="usum_idpe_hidden"></td>
						</tr>		
					</table>
				</tr>
			</table>
			<br/><br/>
			<button name="boton" title="Guardar" style="border-width: 0px; background:white;" onmousedown="tresult()" type="submit"><img src="../imag/icons/PNG_32x32/Save.png" title="Guardar"></button> &nbsp;&nbsp
			<img src="../imag/icons/PNG_32x32/limpiar.png"  onclick="limp_nuev_usua()" title="Limpiar"> &nbsp;&nbsp;
			<img src="../imag/icons/PNG_32x32/Undo.png" onclick="mostrarFornulario()" title="Regresar">
			</center>
			<div class="modal fade" id="myModal" role="dialog">
				<div class="modal-dialog modal-lg">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title">Habilidades</h4>';
							if($donde == "modificar") {
								$this->paginarHabilidades('modificar',$usum_idxx);
							}
							else{
								$this->paginarHabilidades('nuevo','0');
							}
						echo'
						</div>
						<div class="modal-body">
							<div></div>
						</div>
						<div class="modal-footer">
						</div>
		</form></div>';
	}
	
	public function guardarUsuario(){
		$fechaActual = date("Y-m-d H:i:s");
		$Actual = date("H:i:s");
		extract($_REQUEST);
		//$this->insertar("usua_maes","usum_cedu","'$usum_cedu'");
		$this->insertar("usua_maes","usum_iden,usum_nomb,usum_apel,usum_dire,usum_tele,usum_movi,usum_emai,usum_prof,usum_foto,usum_fech,usum_idpe,usum_cont,usum_usua,usum_idem","'$usum_iden','".strtoupper($usum_nomb)."','".strtoupper($usum_apel)."','".strtoupper($usum_dire)."','$usum_tele','$usum_movi','".strtolower($usum_emai)."','".strtoupper($usum_prof)."','$usum_foto_vali','$fechaActual','$usum_idpe','".md5($usum_pass)."',".$this->id_user.",".$_SESSION["empm_idxx"]);
		$sqlusuarios = $this->consultar("usua_maes ", "", "usum_iden=$usum_iden",1);
		$datosusuarios = mysql_fetch_array($sqlusuarios);
		return $datosusuarios["usum_idxx"];
	}

	//Guardar havilidades
	public function guardarHavilidades($trae){
		extract($_POST);
		$fechaActual = date("Y-m-d H:i:s");
		$this->eliminar("deta_haag","dhaa_iush=$trae");
		$vectorIdxMatrisVector = explode(",", $vectorIdxMatris);
		$vectorradioVector = explode(",", $vectorradio);
		$longitud = count($vectorIdxMatrisVector);
		for ($i=0 ; $i < $longitud; $i++){
			if($vectorIdxMatrisVector[$i] != "" ){ 
				$this->insertar("deta_haag","dhaa_idha,dhaa_iush,dhaa_punt,dhaa_fech,dhaa_idus",$vectorIdxMatrisVector[$i].",$trae,".$vectorradioVector[$i].",'$fechaActual',".$_SESSION["usum_idxx"]);
			}
		}
	}

	public function paginarRegistros(){
		$this->limpiarPaginador();
		$sqlusuarios = $this->consultar("usua_maes ", "", "usum_esta='ACT' order by (usum_nomb) asc", 1);
		while($datosusuarios = mysql_fetch_array($sqlusuarios)) {
			$usum_idxx = $datosusuarios["usum_idxx"];
			$usum_nomb = $datosusuarios["usum_nomb"];
			$usum_iden = $datosusuarios["usum_iden"];
			$usum_apel = $datosusuarios["usum_apel"];
			$usum_fech = $datosusuarios["usum_fech"];
			$sqlPerfMaes = $this->consultar("perf_maes", "", "perm_idxx=".$datosusuarios["usum_idpe"], 1);
			$datosPerfMaes = mysql_fetch_array($sqlPerfMaes);
			$perm_nomb = $datosPerfMaes["perm_nomb"];
			$this->cargarPaginador($usum_idxx,$usum_iden,$usum_nomb,$usum_apel,$usum_fech,$perm_nomb);
		}
	}

	public function cargarPaginador($usum_idxx,$usum_codi,$usum_nomb,$usum_apel,$usum_fech,$perm_nomb){
		//if ($usum_idxx!=1) {
			$this->matrizPaginador[0][$this->cantRegistros]= $usum_idxx;
			$this->matrizPaginador[1][$this->cantRegistros]= $usum_codi;
			$this->matrizPaginador[2][$this->cantRegistros]= $usum_nomb;
			$this->matrizPaginador[3][$this->cantRegistros]= $usum_apel;
			$this->matrizPaginador[4][$this->cantRegistros]= $usum_fech;
			$this->matrizPaginador[5][$this->cantRegistros]= $perm_nomb;
			$this->cantRegistros++;
		//}
	}

	//mostrar_ciudades
	public function mostrar_ciudades(){
		extract($_POST);
		$sqlciudad = $this->consultar("ciud_maes ", "", "cidm_idde=".$depm_idxx." and cidm_esta='ACT'", 1);
		echo '<option value="1">Seleccione</option>';
		while($datosciudad = mysql_fetch_array($sqlciudad)) {
				echo  "<option  value='".$datosciudad["cidm_idxx"]."'>".$datosciudad["cidm_nomb"]."</option>";
		}
	}

	public function mostrarRegistros($pagina){
		$canTotalRegistros = $this->cantRegistros;
			$RegistrosAMostrar = 15;
			$contenidoPaginador = "";
			$this->opciones_usum();
			if($canTotalRegistros > 0)  {
				$paginaBusc = trim($pagina);
				if(!empty($paginaBusc)) {
						$RegistrosAEmpezar= ($paginaBusc-1) * $RegistrosAMostrar;
						$PagAct = $paginaBusc;
					}
					else {
						$RegistrosAEmpezar = 0;
					$PagAct = 1; 
					}
				$paginas = ceil($canTotalRegistros / $RegistrosAMostrar);
				if($canTotalRegistros > 14) {
					$RegistrosAfinalizar = ($PagAct == $paginas) ? ($canTotalRegistros - 1) : ($RegistrosAEmpezar + 14);
					}
				else {
						$RegistrosAfinalizar = $canTotalRegistros - 1;
					}
					$contenidoPaginador .= "<div style='overflow-x:auto;'> <table style='WIDTH:80%' align='center'  class='table table-striped table-borderless table-inverse table-hover thead-inverse termp'>";
					$contenidoPaginador .= "<tr>";
					$contenidoPaginador .= "<td class='cabecera'><label>Identificación</label></td>";
					$contenidoPaginador .= "<td class='cabecera'><label>Nombre</label></td>";
					$contenidoPaginador .= "<td class='cabecera'><label>Apellido</label></td>";
					$contenidoPaginador .= "<td class='cabecera'><label>Perfil</label></td>";
					$contenidoPaginador .= "<td class='cabecera'><label>Fecha vinculación</label></td>";
					//$contenidoPaginador .= "<td class='cabecera'><label>Perfil</label></td>";
					$contenidoPaginador .= "<tr>";

				for($j = $RegistrosAEmpezar; $j <= $RegistrosAfinalizar; $j++) {
					$clase = ($j%2==0) ? "cuerpo2" : "cuerpo";
					$contenidoPaginador .= "<tr>";
					$contenidoPaginador .= "<td class='".$clase."'>".number_format($this->matrizPaginador[1][$j])."</td>";
					$contenidoPaginador .= "<td class='".$clase."'>".$this->matrizPaginador[2][$j]."</td>";
					$contenidoPaginador .= "<td class='".$clase."'>".$this->matrizPaginador[3][$j]."</td>";
					$contenidoPaginador .= "<td class='".$clase."'>".$this->matrizPaginador[5][$j]."</td>";
					$contenidoPaginador .= "<td class='".$clase."'>".$this->matrizPaginador[4][$j]."</td>";
					//$contenidoPaginador .= "<td style='WIDTH:1%' class='".$clase."'>".$this->matrizPaginador[5][$j]."</td>";
					$contenidoPaginador .= "<td   class='".$clase." td_img'><img  onclick='modificarUsuario(".$this->matrizPaginador[0][$j].")' class='icon' src='../imag/icons/PNG_32x32/Pencil.png' title='Editar' ></td>";
					$contenidoPaginador .= "<td class='".$clase." td_img' ><img  onclick='eliminarUsuario(".$this->matrizPaginador[0][$j].")' class='icon' src='../imag/icons/PNG_32x32/Recycle_Bin.png' title='Eliminar' ></td>";
					$contenidoPaginador .= "</tr>";
			}
				$PagAnt = $PagAct-1;
				$PagSig = $PagAct+1;
				$PagUlt = $canTotalRegistros/$RegistrosAMostrar;
				$Res = $canTotalRegistros%$RegistrosAMostrar;
					
		


				if($Res>0) {
		 		$PagUlt=floor($PagUlt)+1;
		 	}	
			$contenidoPaginador .= "<tr class='text-center'>";
	   	$contenidoPaginador .= "<td colspan='5' class='cabecera'>&nbsp;&nbsp;<a class='btn btn-primary' onclick='cambiarPaginaUsuar(1);'>&#171;Primero</a>&nbsp;&nbsp;";
	  	if($PagAct>1) {
	    	$contenidoPaginador .= "&nbsp;&nbsp;<a class='btn btn-primary' onclick=\"cambiarPaginaUsuar('$PagAnt');\">&#171;Anterior</a>&nbsp;&nbsp;";
	    }
			$contenidoPaginador .= "&nbsp;&nbsp;Pagina ".$PagAct."/".$PagUlt."&nbsp;&nbsp;";
	    if($PagAct < $PagUlt) {
	    	$contenidoPaginador .= "&nbsp;&nbsp;<a class='btn btn-primary' onclick=\"cambiarPaginaUsuar('$PagSig');\"> Siguiente&#187;</a>&nbsp;&nbsp;";
	    }
	    $contenidoPaginador .= "&nbsp;&nbsp;<a class='btn btn-primary' onclick=\"cambiarPaginaUsuar('$PagUlt');\">Ultimo&#187;</a>&nbsp;&nbsp;</td>";
	    $contenidoPaginador .= "</tr>";
	    $contenidoPaginador .= "</table>";
			$contenidoPaginador .= "<input type='hidden' name='pagina_actual' id='pagina_actual' value='$PagAct'/>"; 

				}
			else {
				$contenidoPaginador .= "<h3><font color='#CCCCCC'><center> No se encontraron registros.</center></font> </h3> ";

			} 
			echo $contenidoPaginador;
	}

	//verificar_cedula
	public function verificar_cedula(){
		extract($_POST);
		if ($usum_idxx==0) {
			$sqlusuarios = $this->consultar("usua_maes ", "", "usum_esta='ACT' and usum_iden=".$cedula, 1);
			if(mysql_num_rows($sqlusuarios)>0){
				exit("cedu_repe");
			}
			$sqlusuarios = $this->consultar("usua_maes ", "", "usum_esta='INA' and usum_iden=".$cedula, 1);
			if(mysql_num_rows($sqlusuarios)>0){
				exit("cedu_inactiva");
			}
		}
		else{
			$sqlusuarios = $this->consultar("usua_maes ", "", "usum_esta='ACT' and usum_idxx!=".$usum_idxx." and usum_iden=".$cedula, 1);
			if(mysql_num_rows($sqlusuarios)>0){
				exit("cedu_repe");
			}
			$sqlusuarios = $this->consultar("usua_maes ", "", "usum_esta='INA' and usum_idxx=".$usum_idxx." and usum_iden=".$cedula, 1);
			if(mysql_num_rows($sqlusuarios)>0){
				exit("cedu_inactiva");
			}
		}
	}

	public function opciones_usum(){
		$contenidoPaginadorw = "<table style='WIDTH:10%' align='center'  class='table table-striped table-borderless table-inverse table-hover thead-inverse '>";
		$sqlusuarios = $this->consultar("usua_maes ", "", "usum_esta='ACT'", 1);
			if(mysql_num_rows($sqlusuarios)>=20){
				$contenidoPaginadorw .= "<td class=' td_img'  ><input type='text' name='buscar_usum'  id='buscar_usum'></td>";
				$contenidoPaginadorw .= "<td class=' td_img'  onclick='busc_aban_usum()'><img class='icon' src='../imag/icons/PNG_32x32/Search.png' title='Buscar' ></td>";
			}
			$contenidoPaginadorw .= "<td class=' td_img'  onclick='nuevoUsuario()'><img class='icon' src='../imag/icons/PNG_32x32/+.png' title='Agregar usumrtamento' ></td>";
			$contenidoPaginadorw .= "<td class=' td_img' ><img onclick='salirAPlantilla()' class='icon' src='../imag/icons/PNG_32x32/Undo.png' title='Salir' ></td>";
			$contenidoPaginadorw .= "</table>";
			echo $contenidoPaginadorw;
	}

	//Eliminar el usumrtamento
	public function eliminarUsuario(){
		extract($_POST);
		//$this->eliminar("usum_maes","usum_idxx=$usum_idxx");
			$this->actualizar("usua_maes", "usum_esta='INA'", "usum_idxx=$usum_idxx");
			//$this->mostrarFornulario();
		
	}

	public function enviar_reporte_pago(){
		extract($_POST);
		$cod=$_SESSION["codigo_cliente"];
		$upload_folder ='images';
		$nombre_archivo = $_FILES['archivo']['name'];
		$tmp_archivo = $_FILES['archivo']['tmp_name'];
		$archivador = $cod."-Registro Tributario";

		if (!move_uploaded_file($tmp_archivo, $archivador)) {

			echo "<script>alert('Error al ingresar el archivo');</script>";
		}
		else{
			echo "<script>alert('Actualizacion exitosa.'); </script>";
		}
	}

	//modificar usumrtamento
	public function modificarUsuario(){
		extract($_REQUEST);
		$sqlusuarios = $this->consultar("usua_maes", "", "usum_idxx='$usum_idxx'",1);
		$datosusuarios = mysql_fetch_array($sqlusuarios);
		$this->formulario("modificar",$datosusuarios["usum_idxx"],$datosusuarios["usum_iden"],$datosusuarios["usum_nomb"],$datosusuarios["usum_apel"],$datosusuarios["usum_dire"],$datosusuarios["usum_tele"],$datosusuarios["usum_movi"],$datosusuarios["usum_emai"],$datosusuarios["usum_idpe"],$datosusuarios["usum_foto"],$datosusuarios["usum_prof"]);
	}


	//activar usuario 
	public function activarUsua(){
		extract($_POST);
		$this->actualizar("usua_maes", "usum_esta='ACT'","usum_iden='$cedula'");
	}
	

	public function busc_aban_usum(){
		extract($_POST);
		$this->limpiarPaginador();
		$sqlusuarios = $this->consultar("usua_maes ", "", "(usum_iden ='".$buscar_usum."' or usum_nomb LIKE '%".$buscar_usum."%' or usum_apel LIKE '%".$buscar_usum."%') and usum_esta='ACT'  order by (usum_nomb) asc" , 1);
		while($datosusuarios = mysql_fetch_array($sqlusuarios)) {
			$usum_idxx = $datosusuarios["usum_idxx"];
			$usum_iden = $datosusuarios["usum_iden"];
			$usum_nomb = $datosusuarios["usum_nomb"];
			$usum_apel = $datosusuarios["usum_apel"];
			$usum_fech = $datosusuarios["usum_fech"];
			$sqlPerfMaes = $this->consultar("perf_maes", "", "perm_idxx=".$datosusuarios["usum_idpe"], 1);
			$datosPerfMaes = mysql_fetch_array($sqlPerfMaes);
			$perm_nomb = $datosPerfMaes["perm_nomb"];
			$this->cargarPaginador($usum_idxx,$usum_iden,$usum_nomb,$usum_apel,$usum_fech,$perm_nomb);
		}
			$this->mostrarRegistros(1);
	}
	public function paginarHabilidades($donde,$usum_idxx){
		$this->limpiarHabilidades();
		$sqlhabilidades = $this->consultar("habi_maes ", "", "habm_esta='ACT'", 1);

		while($datoshabilidaes = mysql_fetch_array($sqlhabilidades)) {
			$hamb_idxx = $datoshabilidaes["habm_idxx"];
			$hamb_nomb = $datoshabilidaes["habm_nomb"];
			$this->cargarHabilidades($hamb_idxx,$hamb_nomb);
		}
		$this->mostrarHabilidades($donde,$usum_idxx);
	}

	public function mostrarHabilidades($donde,$usum_idxx){
		$contenidoPaginador = "<input type='hidden' name='cantRegistrosHabilidades' id='cantRegistrosHabilidades' value='".$this->cantRegistrosHabilidades."'>";
		$contenidoPaginador .= "<input type='hidden' name='vectorIdxMatris' id='vectorIdxMatris' value=''>";
		$contenidoPaginador .= "<input type='hidden' name='vectorradio' id='vectorradio' value=''>";
		$contenidoPaginador .= "<table style='WIDTH:10%' align='center'  class='table table-borderless table-inverse table-hover thead-inverse '>";
		$contenidoPaginador .= "<tr>";
		$contenidoPaginador .= "<td class='cabecera'></td>";
		$contenidoPaginador .= "<td class='cabecera'><label>HABILIDAD</label></td>";
		$contenidoPaginador .= "<td class='cabecera'><label>1</label></td>";
		$contenidoPaginador .= "<td class='cabecera'><label>2</label></td>";
		$contenidoPaginador .= "<td class='cabecera'><label>3</label></td>";
		$contenidoPaginador .= "<td class='cabecera'><label>4</label></td>";
		$contenidoPaginador .= "<td class='cabecera'><label>5</label></td>";
		$contenidoPaginador .= "<tr>";
		for($j = 1; $j <= $this->cantRegistrosHabilidades-1; $j++) {
			$contenidoPaginador .= "<tr>";
			if ($donde=="modificar") {
				$detahabilidades = $this->consultar("deta_haag ", "", "dhaa_idha=".$this->matrizHabilidades[0][$j]." and dhaa_esta='ACT' and dhaa_iush=".$usum_idxx);
				$tnumRadio = 0;
				if ($detahabilidades == 0) {
					$contenidoPaginador .= "<td><input type='checkbox' name='check".$j."' id='check".$j."' onclick='validarCheckHabilidades(".$j.");' value='".$this->matrizHabilidades[0][$j]."'></td>";
				}
				else{
					$contenidoPaginador .= "<td><input type='checkbox' name='check".$j."' id='check".$j."' checked onclick='validarCheckHabilidades(".$j.");' value='".$this->matrizHabilidades[0][$j]."'></td>";
					$tnumRadio = $detahabilidades["dhaa_punt"];
				}
			}
			else{
				$contenidoPaginador .= "<td><input type='checkbox' name='check".$j."' id='check".$j."' onclick='validarCheckHabilidades(".$j.");' value='".$this->matrizHabilidades[0][$j]."'></td>";
			}
			$contenidoPaginador .= "<td >".$this->matrizHabilidades[1][$j]."</td>";
			// 1 
			if ($donde=="modificar") {
				$contenidoPaginador .= ($tnumRadio==1) ? "<td><input type='radio' name='radioHavilidad".$j."' id='1radioHavilidad".$j."' checked onclick='validarRadioHavilidades(".$j.",1)' value='1'></td> " : "<td><input type='radio' name='radioHavilidad".$j."' id='1radioHavilidad".$j."' onclick='validarRadioHavilidades(".$j.",1)' value='1'></td>";
			}
			else{
				$contenidoPaginador .= " <td><input type='radio' name='radioHavilidad".$j."' id='1radioHavilidad".$j."' onclick='validarRadioHavilidades(".$j.",1)' value='1'></td> ";
			}
			// 2
			if ($donde=="modificar") {
				$contenidoPaginador .= ($tnumRadio==2) ? "<td><input type='radio' name='radioHavilidad".$j."' id='2radioHavilidad".$j."' checked onclick='validarRadioHavilidades(".$j.",2)' value='2'></td>" : "<td><input type='radio' name='radioHavilidad".$j."' id='2radioHavilidad".$j."' onclick='validarRadioHavilidades(".$j.",2)' value='2'></td>";
			}
			else{
				$contenidoPaginador .= " <td><input type='radio' name='radioHavilidad".$j."' id='2radioHavilidad".$j."' onclick='validarRadioHavilidades(".$j.",2)' value='2'></td> ";
			}
			// 3
			if ($donde=="modificar") {
				$contenidoPaginador .= ($tnumRadio==3) ? "<td><input type='radio' name='radioHavilidad".$j."' id='3radioHavilidad".$j."' checked onclick='validarRadioHavilidades(".$j.",3)' value='3'></td>" : "<td><input type='radio' name='radioHavilidad".$j."' id='3radioHavilidad".$j."' onclick='validarRadioHavilidades(".$j.",3)' value='3'></td>";
			}
			else{
				$contenidoPaginador .= " <td><input type='radio' name='radioHavilidad".$j."' id='3radioHavilidad".$j."' onclick='validarRadioHavilidades(".$j.",3)' value='3'></td> ";
			}
			// 4
			if ($donde=="modificar") {
				$contenidoPaginador .= ($tnumRadio==4) ? "<td><input type='radio' name='radioHavilidad".$j."' id='4radioHavilidad".$j."' checked onclick='validarRadioHavilidades(".$j.",4)' value='4'></td>" : "<td><input type='radio' name='radioHavilidad".$j."' id='4radioHavilidad".$j."' onclick='validarRadioHavilidades(".$j.",4)' value='4'></td>";
			}
			else{
				$contenidoPaginador .= " <td><input type='radio' name='radioHavilidad".$j."' id='4radioHavilidad".$j."' onclick='validarRadioHavilidades(".$j.",4)' value='4'></td> ";
			}
			// 5
			if ($donde=="modificar") {
				$contenidoPaginador .= ($tnumRadio==5) ? "<td><input type='radio' name='radioHavilidad".$j."' id='5radioHavilidad".$j."' checked onclick='validarRadioHavilidades(".$j.",5)' value='5'></td>" : "<td><input type='radio' name='radioHavilidad".$j."' id='5radioHavilidad".$j."' onclick='validarRadioHavilidades(".$j.",5)' value='5'></td>";
			}
			else{
				$contenidoPaginador .= " <td><input type='radio' name='radioHavilidad".$j."' id='5radioHavilidad".$j."' onclick='validarRadioHavilidades(".$j.",5)' value='5'></td> ";
			}
			$contenidoPaginador .= "<td></td>";
			$contenidoPaginador .= "</tr>";
		}
		echo $contenidoPaginador;
	}
		public function cargarHabilidades($hamb_idxx,$hamb_nomb){
		$this->matrizHabilidades[0][$this->cantRegistrosHabilidades]= $hamb_idxx;
		$this->matrizHabilidades[1][$this->cantRegistrosHabilidades]= $hamb_nomb;
		$this->cantRegistrosHabilidades++;
	}
	public function limpiarHabilidades(){
			unset($this->matrizHabilidades);
			$this->cantRegistrosHabilidades = 1;
	}
	public function limpiarPaginador(){
			unset($this->matrizPaginador);
			$this->cantRegistros = 0;
	}
}
@session_start();
if(empty($_SESSION["obj_maesUsua"])){
	$_SESSION["obj_maesUsua"] = new MaestroUsuario();
}
?>
