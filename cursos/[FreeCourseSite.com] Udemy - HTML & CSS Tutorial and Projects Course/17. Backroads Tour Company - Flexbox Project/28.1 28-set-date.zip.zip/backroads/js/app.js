// testing file
// console.log("hello world");
// ********* set date ************
const date = (document.getElementById(
  "date"
).innerHTML = new Date().getFullYear());
