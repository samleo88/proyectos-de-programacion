<?php
	include_once "../../back_end/BESTUD.php";
	$coneccion = new estudiantes();
	switch ($_REQUEST["accion"]) {
	    case "buscarPublicaciones":
	    	$coneccion->buscarPublicaciones();
        break;
	    case "postularse":
	    	$coneccion->postularse();
        break;
	    case "guardar":
	    	$coneccion->guardar();
        break;
	    case "detallePublicacion":
	    	$coneccion->detallePublicacion();
        break;
	    case "cambiarPaginaPublicaciones":
	    	$coneccion->mostrarRegistrosPublicaciones($_REQUEST["pagina"]);
        break;
	    /*case label2:
	        code to be executed if n=label2;
	        break;
	    ...
	    default:
	        code to be executed if n is different from all labels;*/
	}
?>