//alerta de registros almacenados
function in_almacenado(){
	swal({
    title: "Almacenamiento exitoso",
    text: "",
    type: "success",
    timer: 2000,
    showConfirmButton: false
  });
}
// alerta modificacion alamcenada
function in_modificacion(){
  swal({
    title: "Modificacion exitosa",
    text: "",
    type: "success",
    timer: 2000,
    showConfirmButton: false
  });
}
//alerta de restringir caracteres especiales
function in_texto(){
	swal({
    title: "",
    text: "Este campo no permite caracteres especiales",
    type: "error",
    timer: 3000,
    showConfirmButton: false
  });
}

//alerta de registros vacios
function in_vacios(){
	swal({
    title: "",
    text: "Dato no puede ser vacio",
    type: "error",
    timer: 3000,
    showConfirmButton: false
  });
}

//alerta de registros depenede de otra informacion en otras tablas
function in_dependencias(){
	swal({
    title: "",
    text: "No se puede eliminar porque tiene asociacion",
    type: "error",
    timer: 3000,
    showConfirmButton: false
  });
}

//alerta de permisos de diferentes modulos
function in_permisos(){
	swal({
    title: "",
    text: "Usuario no tiene permisos para este modulo",
    type: "error",
    timer: 3000,
    showConfirmButton: false
  });
}

//alerta de registros con correo invalido
function in_correo(){
	swal({
    title: "",
    text: "Correo electronico incorrecto",
    type: "error",
    timer: 3000,
    showConfirmButton: false
  });
}

//alerta de sesion finalizada
function in_sesion(){
	swal({
    title: "",
    text: "Su sesion ha sido cancelada",
    type: "warning",
    showConfirmButton: true
  });
}

//alerta de registros ya existe
function in_regexis(){
	swal({
    title: "",
    text: "Registro ya existente",
    type: "warning",
    timer: 3000,
    showConfirmButton: false
  });
}
//esta es la funcion para eliminar, esta funcion se hace independiente (en el fron-end)
/*function in_eliminar(){
  swal({
  title: "Are you sure?",
  text: "You will not be able to recover this imaginary file!",
  
  showCancelButton: true,
  confirmButtonColor: "#DD6B55",
  confirmButtonText: "Eliminar",
  closeOnConfirm: false
},
function(){
  swal("Registro eliminado", "", "success");
});
}*/
//esta es la funcion para un mensaje con input, esta funcion se hace independiente (en el fron-end)
/*function in_input(){
  swal({
  title: "An input!",
  text: "Write something interesting:",
  type: "input",
  showCancelButton: true,
  closeOnConfirm: false,
  animation: "slide-from-top",
  inputPlaceholder: "Write something"
},
function(inputValue){
  if (inputValue === false) return false;
  
  if (inputValue === "") {
    swal.showInputError("You need to write something!");
    return false
  }
  
  swal("Nice!", "You wrote: " + inputValue, "success");
});
}*/
//http://t4t5.github.io/sweetalert/