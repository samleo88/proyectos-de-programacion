<?php
require_once("../../back/BAUSUA_MAES-V10.php");
	$accion = $_REQUEST["accion"];
	switch ($accion) {
		// guardar departamentos
		case 'guardarUsuario':
			$_SESSION["obj_maesUsua"]->guardarUsuario();
		break;
		// verificar_cedula
		case 'verificar_cedula':
			$_SESSION["obj_maesUsua"]->verificar_cedula();
		break;

		//mostrar formulario al que va dirigido  
		case 'mostrarFornulario':
			$_SESSION["obj_maesUsua"]->mostrarFornulario();
		break;

		case 'paginarHabilidades':
		$_SESSION["obj_maesUsua"]->paginarHabilidades();
		break;
		//mostrar_ciudades
		case 'mostrar_ciudades':
		$_SESSION["obj_maesUsua"]->mostrar_ciudades();
		break;
		// crear nuevo departamento
		case 'nuevoUsuario':
			$_SESSION["obj_maesUsua"]->formulario();
		break;
		// crear nuevo departamento
		case 'enviar_reporte_pago':
			$_SESSION["obj_maesUsua"]->enviar_reporte_pago();
		break;

		// modificar Departamento
		case 'modificarUsuario':
			$_SESSION["obj_maesUsua"]->modificarUsuario();
		break;

		// activar Usuario
		case 'activarUsua':
			$_SESSION["obj_maesUsua"]->activarUsua();
		break;

		//Guardar mdificaciones de habilidades
		case 'guar_modi_usua':
			$_SESSION["obj_maesUsua"]->guar_modi_usua();
		break;
		// inactivar departamento
		case 'eliminarUsuario':
			$_SESSION["obj_maesUsua"]->eliminarUsuario();
		break;

		// busqueda avanzada de deparatamento
		case 'busc_aban_usum':
			$_SESSION["obj_maesUsua"]->busc_aban_usum();
		break;

		// busqueda avanzada de deparatamento
		case 'guardar_foto':
			$donde = $_REQUEST["donde"];
			$usum_idxx = $_REQUEST["usum_idxx"];
			$usum_iden = $_REQUEST["usum_iden"];
			$usum_idpe = $_REQUEST["usum_idpe_hidden"];
			$usum_nomb = $_REQUEST["usum_nomb"];
			$usum_apel = $_REQUEST["usum_apel"];
			$usum_dire = $_REQUEST["usum_dire"];
			$usum_tele = $_REQUEST["usum_tele"];
			$usum_prof = $_REQUEST["usum_prof"];
			$usum_movi = $_REQUEST["usum_movi"];
			$usum_emai = $_REQUEST["usum_emai"];
			$usum_pass = $_REQUEST["usum_pass"];
			$usum_foto_vali = $_REQUEST["usum_foto_vali"];
			if ($donde == "modificar") {
				$trae = $_SESSION["obj_maesUsua"]->guar_modi_usua();
			}
			else{
				$trae = $_SESSION["obj_maesUsua"]->guardarUsuario();
				//$donde,$usum_idxx,$usum_idex,$usum_cedu,$usum_idde,$usum_idci,$usum_nomb,$usum_apell,$usum_fena,$usum_dire,$usum_barr,$usum_tele,$usum_celu,$usum_core,$usum_fevi,$usum_pass
			}
		
			if ((($_FILES["file"]["type"] == "image/gif")
				|| ($_FILES["file"]["type"] == "image/jpeg")
				|| ($_FILES["file"]["type"] == "image/png")
				|| ($_FILES["file"]["type"] == "image/pjpeg"))
				&& ($_FILES["file"]["size"] < 2000000)){
	  		if ($_FILES["file"]["error"] > 0){
		  		//echo "File Error :  " . $_FILES["file"]["error"] . "<br />";
	    	}else {
		  		if (file_exists("images/".$trae)){
			   		//echo "<b>".$_FILES["file"]["name"] . " already exists. </b>";
			   		//move_uploaded_file($_FILES["file"]["tmp_name"],"images/". $_FILES["file"]["name"]);
			   		//move_uploaded_file($_FILES["file"]["tmp_name"],"../../imag/empleados/". $trae .".jpg");
			   		move_uploaded_file($_FILES["file"]["tmp_name"],"../../imag/empleados/". $trae .".jpg");
					}else{
			   		move_uploaded_file($_FILES["file"]["tmp_name"],"../../imag/empleados/". $trae .".jpg");
		   		}
				}
	  	}else{
	  		// echo "Invalid file detail ::<br> file type ::".$_FILES["file"]["type"]." , file size::: ".$_FILES["file"]["size"];
			}
			echo "<script> location.href='../../fron/FRUSUA_MAES-V10.php';</script>";
		break;

		//cambiar el paginador de la pagina actual
		case 'cambiarPaginaUsuar':
			$pagina = $_REQUEST["pagina"];
			$_SESSION["obj_maesUsua"]->mostrarRegistros($pagina);
		break;
		
		default:
			exit("Usted no tiene permisos para acceder a este modulo!");
		break;
	}
	
?>