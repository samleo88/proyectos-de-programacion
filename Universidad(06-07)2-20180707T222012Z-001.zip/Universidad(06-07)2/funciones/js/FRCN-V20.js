// funcion que solo permite numeros en el documento
 function solonumeros(e)
	{
       key = e.keyCode || e.which;
       tecla = String.fromCharCode(key).toLowerCase();
       numeros = "0123456789";
       especiales = [8,9,11,13,37,38,39,40,116,190];

       tecla_especial = false
       for(var i in especiales)
	    {
            if(key == especiales[i])
			{
                tecla_especial = true;
                break;
            }
        }

        if(numeros.indexOf(tecla)==-1 && !tecla_especial)
		{
            return false;
        }
    }

 function solonumero(e)
	{
       key = e.keyCode || e.which;
       tecla = String.fromCharCode(key).toLowerCase();
       numeros = "0123456789";
       especiales = [8,9,11,13,37,38,39,40,116,190];

       tecla_especial = false
       for(var i in especiales)
	    {
            if(key == especiales[i])
			{
                tecla_especial = true;
                break;
            }
        }

        if(numeros.indexOf(tecla)==-1 && !tecla_especial)
		{
            return false;
        }
		var docto = document.getElementById('docto').val;
		if (docto != "" )
		 { 
		  document.getElementById('1').checked = false;
          document.getElementById('2').checked = false;
		  document.getElementById("select").innerHTML="";
		 } 
    }
 	
  