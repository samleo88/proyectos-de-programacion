<?php
	include_once "../../back_end/BUNIVE.php";
	$coneccion = new estudiantes();
	switch ($_REQUEST["accion"]) {
	    case "buscarPublicaciones":
	    	$coneccion->buscarPublicaciones();
        break;
	    case "verPostulados":
	    	$coneccion->verPostulados();
        break;
	    case "guardar":
	    	$coneccion->guardar();
        break;
	    case "detallePublicacion":
	    	$coneccion->detallePublicacion();
        break;
	    case "cambiarPaginaPublicaciones":
	    	$coneccion->mostrarRegistrosPublicaciones($_REQUEST["pagina"]);
        break;
	    case "formularioNuevaPublicacion":
	    	$coneccion->formularioNuevaPublicacion();
        break;
	    case "guardarPublicacion":
			$extension = $_REQUEST["extension"];

	    	/*if ((($_FILES["file"]["type"] == "image/gif")
				|| ($_FILES["file"]["type"] == "image/jpeg")
				|| ($_FILES["file"]["type"] == "image/png")
				|| ($_FILES["file"]["type"] == "image/pjpeg"))
				&& ($_FILES["file"]["size"] < 2000000)){
		  		if ($_FILES["file"]["error"] > 0){
			  		//echo "File Error :  " . $_FILES["file"]["error"] . "<br />";
		    	}else {*/
			  		//if (file_exists("images/".$trae)){
				   		//echo "<b>".$_FILES["file"]["name"] . " already exists. </b>";
				   		//move_uploaded_file($_FILES["file"]["tmp_name"],"images/". $_FILES["file"]["name"]);
				   		//move_uploaded_file($_FILES["file"]["tmp_name"],"../../imag/empleados/". $trae .".jpg");
				   		move_uploaded_file($_FILES["file"]["tmp_name"],"../../imagenes/publicaciones/1.".$extension);
						/*}else{
				   		move_uploaded_file($_FILES["file"]["tmp_name"],"../../imag/empleados/". $trae .".jpg");
			   		}*/
				/*}
		  	}*/
        break;
	}
?>