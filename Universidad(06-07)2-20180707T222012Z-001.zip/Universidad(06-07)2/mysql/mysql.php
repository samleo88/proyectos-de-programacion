<?php
class conectarBD
{
	public $conexion;
	public $con_serv;
	public $con_base;
	public $con_user;
	public $con_pass;
	public $error;
	function __construct(){
	}

	public function conectarBD(){
		$this->con_serv = "localhost";
		$this->con_base = "universidades";
		$this->con_user = "root";
		$this->con_pass = "";		
		$this->conexion = mysql_connect($this->con_serv, $this->con_user, $this->con_pass) or die("Error conectando a la base de datos.". mysql_error());
		$BD = mysql_select_db($this->con_base, $this->conexion) or die ("Error seleccionando la base de datos.". mysql_error());
		
		mysql_query("SET NAMES 'utf8'");
	}

	public function actualizar($tabla, $campos, $condiciones)
	{
		$this->conectarBD();
		$sqlUpdate = ('UPDATE ' .$tabla. ' SET '.$campos.' WHERE '.$condiciones);
		mysql_query($sqlUpdate, $this->conexion) or die (mysql_error());
		return mysql_affected_rows();
	}

	public function eliminar($tabla,$condiciones)
  	{
  		$this->conectarBD();
		$sqlDelete =('DELETE FROM '.$tabla.' WHERE '.$condiciones);
		mysql_query($sqlDelete, $this->conexion) or die (mysql_error());
		return mysql_affected_rows();
  	} 

	public function insertar($tabla,$campos,$valores)
	{
		$this->conectarBD();
		$sqlInsert = ('INSERT INTO '.$tabla.'('.$campos.') VALUES ('.$valores.')');
		$result = mysql_query($sqlInsert, $this->conexion) or die (mysql_error());
		return mysql_insert_id();
	}
	public function tablas($tablas){
		$this->conectarBD();
 		$queryConsulta = mysql_query($tablas, $this->conexion) or die ("Error en consulta $sqlConsulta ". mysql_error());
 		return $queryConsulta;
	}

	public function consultar( $atributos = "",$tablas = "", $condiciones = "", $tipoConsulta = "")
 	{
 		$this->conectarBD();
 		$atributos = ($atributos == "") ? "*" : $atributos;
 		$condiciones = ($condiciones == "") ? "" : "WHERE ".$condiciones;
 		$sqlConsulta = ('SELECT '.$atributos.' FROM '.$tablas.' '.$condiciones);
 		$queryConsulta = mysql_query($sqlConsulta, $this->conexion) or die ("Error en consulta $sqlConsulta ". mysql_error());
 		return $queryConsulta;
 	}
}


?>