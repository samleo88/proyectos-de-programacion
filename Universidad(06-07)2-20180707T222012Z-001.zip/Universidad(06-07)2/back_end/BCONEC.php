<?php
	include_once "../../mysql/mysql.php";

	/**
	 * 
	 */
	class Coneccion extends conectarBD
	{
		
		/*function __construct(argument)
		{
			# code...
		}*/

		//validarIngreso
		public function validarIngreso(){
			extract($_POST);
			switch ($tipoUsuiario) {
				case 'estudiante':
					$this->buscarEstudiante();
				break;
				
				case 'universidad':
					$this->buscarUniversidad();
				break;
				
				case 'administrador':
					$this->buscarAdministrador();
				break;
			}
			
		}

		//buscarEstudiante
		private function buscarEstudiante(){
			extract($_POST);
			$sqlCandidato = $this->consultar("","candidato","(cand_nomb='".$usuario."' or cand_corr='".$usuario."')");
			if (mysql_num_rows($sqlCandidato)>0) {
				mysql_data_seek($sqlCandidato,0);
				$datosCandidato = mysql_fetch_array($sqlCandidato);
				if ($datosCandidato["cand_nuin"]==5) {
					exit("sobrepasoNumeroDeIntentos");
				}
				$sqlCandidatoCont = $this->consultar("","candidato","cand_cont='".$contrasena."' and cand_idxx=".$datosCandidato["cand_idxx"]);
				if (mysql_num_rows($sqlCandidatoCont)>0) {
					$this->actualizar("candidato","cand_nuin=0","cand_idxx=".$datosCandidato["cand_idxx"]);
					$_SESSION["cand_idxx"]=$datosCandidato["cand_idxx"];
					$_SESSION["tipo"]="cand";
					exit("correcto") ;
				}
				else{
					$cand_nuin = $datosCandidato["cand_nuin"] + 1;
					$this->actualizar("candidato","cand_nuin=".$cand_nuin,"cand_idxx=".$datosCandidato["cand_idxx"]);
					exit("errorContraseña");					
				}
			}
			else{
				exit("errorUsuario");
			}
		}

		//buscarUniversidad
		private function buscarUniversidad(){
			extract($_POST);
			$sqlUniversidad = $this->consultar("","universidad","(univ_raso='".$usuario."' or univ_corr='".$usuario."')");
			if (mysql_num_rows($sqlUniversidad)>0) {
				mysql_data_seek($sqlUniversidad,0);
				$datosUniversidad = mysql_fetch_array($sqlUniversidad);
				if ($datosUniversidad["univ_nuin"]==5) {
					exit("sobrepasoNumeroDeIntentos");
				}
				$sqlAdministradorCont = $this->consultar("","universidad","univ_cont='".$contrasena."' and univ_idxx=".$datosUniversidad["univ_idxx"]);
				if (mysql_num_rows($sqlAdministradorCont)>0) {
					$this->actualizar("universidad","univ_nuin=0","univ_idxx=".$datosUniversidad["univ_idxx"]);
					$_SESSION["cand_idxx"]=$datosUniversidad["univ_idxx"];
					$_SESSION["tipo"]="univ";
					exit("correcto") ;
				}
				else{
					$univ_nuin = $datosUniversidad["univ_nuin"] + 1;
					$this->actualizar("universidad","univ_nuin=".$univ_nuin,"univ_idxx=".$datosUniversidad["univ_idxx"]);
					exit("errorContraseña");					
				}
			}
			else{
				exit("errorUsuario");
			}
		}

		//buscarAdministrador
		private function buscarAdministrador(){
			extract($_POST);
			$sqlAdministrador = $this->consultar("","administrador","(admi_nomb='".$usuario."' or admi_corr='".$usuario."')");
			if (mysql_num_rows($sqlAdministrador)>0) {
				mysql_data_seek($sqlAdministrador,0);
				$datosAministrador = mysql_fetch_array($sqlAdministrador);
				if ($datosAministrador["admi_nuin"]==5) {
					exit("sobrepasoNumeroDeIntentos");
				}
				$sqlAdministradorCont = $this->consultar("","administrador","admi_cont='".$contrasena."' and admi_idxx=".$datosAministrador["admi_idxx"]);
				if (mysql_num_rows($sqlAdministradorCont)>0) {
					$this->actualizar("administrador","admi_nuin=0","admi_idxx=".$datosAministrador["admi_idxx"]);
					$_SESSION["cand_idxx"]=$datosAministrador["admi_idxx"];
					$_SESSION["tipo"]="admi";
					exit("correcto") ;
				}
				else{
					$admi_nuin = $datosAministrador["admi_nuin"] + 1;
					$this->actualizar("administrador","admi_nuin=".$admi_nuin,"admi_idxx=".$datosAministrador["admi_idxx"]);
					exit("errorContraseña");					
				}
			}
			else{
				exit("errorUsuario");
			}
		}

		//validarRegistro
		public function validarRegistro(){
			extract($_POST);
			switch ($tipoUsuiario) {
				case 'estudiante':
					$this->registrarEstudiante();
				break;
				case 'universidad':
					$this->registrarUniversidad();
				break;
			}
		}

		//registrarEstudiante
		private function registrarEstudiante(){
			extract($_POST);
			$fechaActual = date("Y-m-d H:i:s");
			$sqlCandidato = $this->consultar("","candidato","(cand_nomb='".$nombre."' or cand_corr='".$correo."')");
			if (mysql_num_rows($sqlCandidato)>0) {
				exit("usuarioExistente");
			}
			$cand_idxx = $this->insertar("candidato","cand_nomb,cand_apel,cand_corr,cand_celu,cand_cont,cand_cedu,cand_nies,cand_fech,cand_esta","'".$nombre."','".$apellido."','".$correo."',".$celular.",'".$contrasena."',".$cedula.",".$nivelEsco.",'".$fechaActual."','ACT'");
			exit("guardadoConExito".$cand_idxx);

		}

		//registrarUniversidad
		private function registrarUniversidad(){
			extract($_POST);
			$fechaActual = date("Y-m-d H:i:s");
			$sqlUniversidad = $this->consultar("","universidad","(univ_raso='".$razonSocial."' or univ_corr='".$correo."')");
			if (mysql_num_rows($sqlUniversidad)>0) {
				exit("usuarioExistente");
			}
			$this->insertar("universidad","univ_raso,univ_nitt,univ_corr,univ_celu,univ_cont,univ_desc,univ_fech,univ_esta","'".$razonSocial."',".$nitt.",'".$correo."',".$celular.",'".$contrasena."','".$descripcion."','".$fechaActual."','PRO'");
			exit("guardadoConExito");
		}


	}




	
?>