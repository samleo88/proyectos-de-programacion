<?php
    include_once "../../mysql/mysql.php";

    /**
     * 
     */
    class estudiantes extends conectarBD
    {
        function __construct()
        {
            $_SESSION["usua_idxx"]=1;
            $this->num_publicaciones = 0;
        }
        
        /*function __construct(argument)
        {
            # code...
        }*/

        //buscarPublicaciones
        public function buscarPublicaciones(){
            extract($_POST);
            $sqlPublicaciones = $this->consultar("","publicaciones","publ_idun=".$_SESSION["usua_idxx"]);
            if (mysql_num_rows($sqlPublicaciones)>0) {
                mysql_data_seek($sqlPublicaciones,0);
                while ($datosPublicaciones = mysql_fetch_array($sqlPublicaciones)) {
                    $sqlUniversidad = $this->consultar("","universidad","univ_idxx=".$datosPublicaciones["publ_idun"]);
                    $datosUniversidad = mysql_fetch_array($sqlUniversidad);
                    $this->matrizPublicaciones($datosUniversidad["univ_raso"],$datosPublicaciones["publ_idxx"],$datosPublicaciones["publ_titu"],$datosPublicaciones["publ_desc"],$datosPublicaciones["publ_fefi"]);
                }
                $this->mostrarRegistrosPublicaciones(1);
            }
            
        }

        // matriz de publicaciones
        public function matrizPublicaciones($univ_raso,$publ_idxx,$publ_titu,$publ_desc,$publ_fefi){
            $this->matrizPublicaciones[0][$this->num_publicaciones]= $univ_raso;
            $this->matrizPublicaciones[1][$this->num_publicaciones]= $publ_idxx;
            $this->matrizPublicaciones[2][$this->num_publicaciones]= $publ_titu;
            $this->matrizPublicaciones[3][$this->num_publicaciones]= $publ_desc;
            $this->matrizPublicaciones[4][$this->num_publicaciones]= $publ_fefi;
            $this->num_publicaciones++;
        }

        //mostrar los registros de los clientes guardados
        public function mostrarRegistrosPublicaciones($pagina){
            $canTotalRegistros = $this->num_publicaciones;
            $RegistrosAMostrar = 15;
            if($canTotalRegistros > 0)  {
                $paginaBusc = trim($pagina);
                if(!empty($paginaBusc)) {
                    $RegistrosAEmpezar= ($paginaBusc-1) * $RegistrosAMostrar;
                    $PagAct = $paginaBusc;
                }
                else {
                    $RegistrosAEmpezar = 0;
                    $PagAct = 1; 
                }
                $paginas = ceil($canTotalRegistros / $RegistrosAMostrar);
                if($canTotalRegistros > 14) {
                    $RegistrosAfinalizar = ($PagAct == $paginas) ? ($canTotalRegistros - 1) : ($RegistrosAEmpezar + 14);
                }
                else {
                    $RegistrosAfinalizar = $canTotalRegistros - 1;
                }
                for($j = $RegistrosAEmpezar; $j <= $RegistrosAfinalizar; $j++) {
                    echo "<div id='publicaciones'>
            <img class='avatar' src='../imagenes/ayudaEstudiante3.jpg' >
            <div id='titulo'>      
              <h3><b>".$this->matrizPublicaciones[0][$j]."</b></h3>
              <br>
            </div>
            <div id='imagen'>
              <img src='../imagenes/ayudaEstudiante3.jpg' style='width:100%;'>
            </div>
            <div class='row' id='descripcion' style='width:100%;'>      
              <h3><b>".$this->matrizPublicaciones[2][$j]."</b></h3>
              <p>".$this->matrizPublicaciones[3][$j]."</p>
              <div class='col-sm-4'><a onclick='verPostulados(".$this->matrizPublicaciones[1][$j].")' class='button'>Ver postulados</a></div>
              <div class='col-sm-4'></div>
              <div class='col-sm-4'><a onclick='detallePublicacion(".$this->matrizPublicaciones[1][$j].")' class='button'>Mas detalles</a></div>
            </div>
          </div>
          <br>";
              //<div class='col-sm-4'><a onclick='guardar(".$this->matrizPublicaciones[1][$j].")' class='button'>Guardar</a></div>
                }
                $PagAnt = $PagAct-1;
                $PagSig = $PagAct+1;
                $PagUlt = $canTotalRegistros/$RegistrosAMostrar;
                $Res = $canTotalRegistros%$RegistrosAMostrar;
                if($Res>0) {
                    $PagUlt=floor($PagUlt)+1;
                }    
                echo "<tr class='text-center'>";
                echo "<td colspan='14' class='cabecera'>&nbsp;&nbsp;<a class='btn btn-primary' onclick='cambiarPaginaPublicaciones(1);'>&#171;Primero</a>&nbsp;&nbsp;";
                if($PagAct>1) {
                    echo "&nbsp;&nbsp;<a class='btn btn-primary' onclick=\"cambiarPaginaPublicaciones('$PagAnt');\">&#171;Anterior</a>&nbsp;&nbsp;";
                }
                echo "&nbsp;&nbsp;Pagina ".$PagAct."/".$PagUlt."&nbsp;&nbsp;";
                if($PagAct < $PagUlt) {
                    echo "&nbsp;&nbsp;<a class='btn btn-primary' onclick=\"cambiarPaginaPublicaciones('$PagSig');\"> Siguiente&#187;</a>&nbsp;&nbsp;";
                }
                echo "&nbsp;&nbsp;<a class='btn btn-primary' onclick=\"cambiarPaginaPublicaciones('$PagUlt');\">Ultimo&#187;</a>&nbsp;&nbsp;</td>";
                echo "</tr>";
                echo "</table>";
                echo "<input type='hidden' name='pagina_actual' id='pagina_actual' value='$PagAct'/>"; 
            }
            else {
                echo "<h3><font color='#CCCCCC'><center> No se encontraron registros.</center></font> </h3> ";
            } 
        }

        //verPostulados
        public function verPostulados(){
            extract($_POST);
            $fechaActual = date("Y-m-d H:i:s");
            $sqlPostulaciones = $this->consultar("","postulaciones","post_idpu=".$publ_idxx);
            if (mysql_num_rows($sqlPostulaciones)>0) {
                echo " 
                    <center>
                        <h3 style='color:#4d4d4d'>Postulados</h3>
                        <hr>
                    <table class='table'>
                ";
                mysql_data_seek($sqlPostulaciones,0);
                while ($datosPostulaciones = mysql_fetch_array($sqlPostulaciones)) {
                    $sqlCandidato = $this->consultar("","candidato","cand_idxx=".$datosPostulaciones["post_idca"]);
                    $datosCandidato = mysql_fetch_array($sqlCandidato);
                    echo " 
                        <tr>
                            <td width='50px' onclick='mostrarAcordion(".$datosCandidato["cand_idxx"].");'>
                                <img class='avatarEstudiantes' src='../imagenes/ayudaEstudiante3.jpg' >
                            </td>
                            <td onclick='mostrarAcordion(".$datosCandidato["cand_idxx"].");'>
                                <h3><b>".$datosCandidato["cand_nomb"]." ".$datosCandidato["cand_apel"]."</b></h3>
                            </td>
                        </tr>
                        <tr>
                            <td colspan='2'>
                                <div onclick='ocultarAcordion(".$datosCandidato["cand_idxx"].");' id='acordion".$datosCandidato["cand_idxx"]."' style='display:none'>
                                    
                                </div>
                            </td>
                        </tr>
                    ";
                }
                echo " 
                    </table>
                </center>
            ";
            }
            else{
                echo " 
                <center>
                    <h3 style='color:#4d4d4d'>No se encontraron postulados</h3>
                </center>
            ";
            }
        }

        //guardar
        public function guardar(){
            extract($_POST);
            $fechaActual = date("Y-m-d H:i:s");
            $this->insertar("guardados","guar_idpu,guar_idca,guar_fech,guar_esta",$publ_idxx.",".$_SESSION["usua_idxx"].",'".$fechaActual."','ACT'");
        }

        //detallePublicacion
        public function detallePublicacion(){
            extract($_POST);
            $sqlPublicaciones = $this->consultar("","publicaciones","publ_idxx=".$publ_idxx);
            $datosPublicaciones = mysql_fetch_array($sqlPublicaciones);
            $sqlDetallePublicacion = $this->consultar("","detalle_publicaciones","depu_idpu=".$publ_idxx);
            $datosDetallePublicacion = mysql_fetch_array($sqlDetallePublicacion);

            switch ($datosDetallePublicacion["depu_reac"]) {
                case 0:
                    $depu_reac ="Baciller";
                break;
                case 1:
                    $depu_reac ="Tecnico";
                break;
                case 2:
                    $depu_reac ="Tecnologo";
                break;
                case 3:
                    $depu_reac ="Universidad";
                break;
            }
            echo " 
                <center>
                    <h3 style='color:#4d4d4d'>Detalle publicacion</h3>
                    <hr>
                    <table class='table'>
                        <tr>
                            <td>
                                <label>Cupos:</label>
                            </td>
                            <td>
                                <label>".$datosDetallePublicacion["depu_cupo"]."</label>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Requisito academico:</label>
                            </td>
                            <td>
                                <label>".$depu_reac."</label>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Costo de la matricula:</label>
                            </td>
                            <td>
                                <label>".number_format($datosDetallePublicacion["depu_coma"])."</label>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Joranada de la matricula:</label>
                            </td>
                            <td>
                                <label>".$datosDetallePublicacion["depu_joma"]."</label>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Ubicacion:</label>
                            </td>
                            <td>
                                <label>".$datosDetallePublicacion["depu_ubic"]."</label>
                            </td>
                        </tr>
                    </table>
                </center>
            ";

        }

        //formularioNuevaPublicacion
        public function formularioNuevaPublicacion(){
            echo '
                <script type="text/javascript">
                    var loadFile = function(event){
                        var output = document.getElementById("usum_foto");
                        output.src = URL.createObjectURL(event.target.files[0]);
                    };
                </script>
                <form  action="../funciones/php/FUNIVER.php" name="formulari" id="formulari" method="post" enctype="multipart/form-data" onSubmit="return validarNuevaPublicacion()" autocomplete="off" >
                    <img src="../imagenes/agregarImagen.jpg" id="usum_foto"/>
                    <input type="hidden"  name="usum_foto_vali" id="usum_foto_vali" value="N">
                    <input type="hidden"  name="accion" id="accion" value="guardarPublicacion">
                    <br>
                    <table align="center"  >
                        <tr>
                            <center><h3>Agregue la imagen</h3></center>
                        </tr>
                        <tr>
                            <td><input type="file" name="file" onchange="loadFile(event)" id="file" /></td>
                        </tr>
                        <tr>
                            <td><input type="hidden" name="description" id="description" />
                            <input type="hidden" name="extension" id="extension" /></td>
                            <td></td>
                        </tr>
                    </table>
                    <table>
                        <tr>
                            <td>
                                <label>Titulo:</label>
                            </td>
                            <td>
                                <input type="text" class="form-control" name="publ_titu" id="publ_titu">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Descrición:</label>
                            </td>
                            <td>
                                <textarea class="form-control" name="publ_desc" id="publ_desc"></textarea>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Fecha de finalización:</label>
                            </td>
                            <td>
                                <input type="date" class="form-control" name="publ_fefi" id="publ_defi" step="1" min="2018-01-01" max="2100-12-31">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Cupos:</label>
                            </td>
                            <td>
                                <input type="text" class="form-control" name="depu_cupo" id="publ_cupo">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Requisito academico:</label>
                            </td>
                            <td>
                                <input type="text" class="form-control" name="depu_reac" id="depu_reac">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Costo:</label>
                            </td>
                            <td>
                                <input type="text" class="form-control" name="depu_coma" id="depu_coma">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Jornada:</label>
                            </td>
                            <td>
                                <input type="text" class="form-control" name="depu_joma" id="depu_joma">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Ubicacion:</label>
                            </td>
                            <td>
                                <input type="text" class="form-control" name="depu_ubic" id="depu_ubic">
                            </td>
                        <tr>
                    </table>
                    <br/><br/>
                    <div class="col-sm-4">
                    </div>
                    <div class="col-sm-2">
                        <button class="button" type="submit">Guardar</button>
                    </div>
                    <div class="col-sm-2">
                        <a onclick="cancelarFormulario()" class="button">Cancelar</a>
                    </div>
                    <div class="col-sm-4">
                    </div>
                </form>
            ';
        }

        // LIMPIAR MATRIZ
        public function limpiar_matriz(){
            unset($this->matrizPublicaciones);
            $this->num_publicaciones=0;
        }

    }
?>

