
function validarEmail(valor,lugar) {
  var atpos = valor.indexOf("@");
  var dotpos = valor.lastIndexOf(".");
  if (atpos<1 || dotpos<atpos+2 || dotpos+2>=valor.length) {
    in_correo();
    $(lugar).focus();
    return "si";
  }
}
//validar caracteres especiales
function caracteresEspeciales(e) { 
  tecla = (document.all) ? e.keyCode : e.which; 
  //alert(tecla);
  if (tecla==8) return true; 
  if (tecla==0) return true; 
  if (tecla==13) return true; 
  patron = /[A-Za-z0-9ñÑ'.,@_\-\s\n]/; 
  te = String.fromCharCode(tecla); 
  return patron.test(te);
}

//Valida que solo numeros 
function solonumeros(dato){
  key = dato.keyCode || dato.which;
  tecla = String.fromCharCode(key).toLowerCase();
  numeros = "0123456789.,";
  especiales = [8,9,11,13];
  tecla_especial = false
  for(var i in especiales){
    if(key == especiales[i]){
      tecla_especial = true;
      break;
    }
  }
  if(numeros.indexOf(tecla)==-1 && !tecla_especial){
    return false;
  }
}
//validar atributos
function validarAtributos(atributos_validar){
  var fLen = atributos_validar.length;
  for (i = 0; i < fLen; i++) {
    if ($(atributos_validar[i]).val() == "" || $(atributos_validar[i]).val() == 0 || $(atributos_validar[i]).val() == "seleccione" || $(atributos_validar[i]).val() == "Seleccione") {
      in_vacios();
      $(atributos_validar[i]).focus();
      return "si";
    }
  }
}

//salir
function salirAPlantilla(){
  location.href = "FRPLANTILLA.php";
}






//forma de usar las validaciones de inputs
/*
letras
 onkeypress="return caracteresEspeciales(event)"
numeros
 onkeypress="return solonumeros(event);"
*/
