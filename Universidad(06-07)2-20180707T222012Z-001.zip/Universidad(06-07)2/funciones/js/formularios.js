//calendario 
//////////////////////////////////////////////////////////////////////////
//En esta funcion elige solo una opcion {Tipo Persona: NORMAL JURIDICA}
    
//////////////////////////////////////////////////////////////////////////
//limpia las casillas al clicar///
  function limpiarcasillas() {
      document.getElementById("formulario").reset();
  }
//////////////////////////////////////////////////////////////////////////
//formato de campo para poner los puntos despues de 3 digitos
	function formatoNumerico(campo) { 
  	var resultado = "";  
    	var numero = campo.value;
    	nuevoNumero=numero.replace(/\./g,'');
    	if(numero.indexOf(",")>=0)
        	nuevoNumero=nuevoNumero.substring(0,nuevoNumero.indexOf(","));
      	for (var j, i = nuevoNumero.length - 1, j = 0; i >= 0; i--, j++)
          	resultado = nuevoNumero.charAt(i) + ((j > 0) && (j % 3 == 0)? ".": "") + resultado;
    		if(numero.indexOf(",")>=0)
      	resultado+=numero.substring(numero.indexOf(","));
    		campo.value= resultado;
	}
//////////////////////////////////////////////////////////////////////////
    
//////////////////////////////////////////////////////////////////////////