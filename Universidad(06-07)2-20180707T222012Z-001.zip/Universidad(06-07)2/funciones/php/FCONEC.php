<?php
	include_once "../../back_end/BCONEC.php";

	$coneccion = new Coneccion();
	switch ($_REQUEST["accion"]) {
	    case "validarIngreso":
	    	$coneccion->validarIngreso();
        break;
	    case "validarRegistro":
	    	$coneccion->validarRegistro();
        break;
	    /*case label2:
	        code to be executed if n=label2;
	        break;
	    ...
	    default:
	        code to be executed if n is different from all labels;*/
	}
?>