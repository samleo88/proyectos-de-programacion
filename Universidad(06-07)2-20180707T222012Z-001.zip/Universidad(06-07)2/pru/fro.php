<?php
	/*$url="FRUSUA_MAES-V10";
	include_once('../func/php/FUSEGURIDAD-V10.php');*/
?>
<!DOCTYPE html>
<html>
<head>
<title>Usuarios</title>
<meta charset="utf-8">
<link rel="shortcut icon" type="image/png" href="../imag/favicon.png"/>
<meta name="viewport" content="width=device-width, initial-scale=1" /> 

<link rel="stylesheet" href="../esti/css/Responsive_V10.css">
<link rel="stylesheet" type="text/css" href="../esti/css/sweetalert.css">
<link rel="stylesheet" href="../esti/css/jquery-ui.css"/>
<link rel="stylesheet" href="../esti/css/bootstrap.min.css"/>

<script type="text/javascript" src="../ajax/jquery-1.9.1.js"></script>
<script type="text/javascript" src="../ajax/jQuery.js"></script>
<script type="text/javascript" src="../ajax/jQuery.alert.js"></script>
<script type="text/javascript" src="../func/js/jquery.min.js"></script>
<script type="text/javascript" src="../func/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../func/js/jquery-ui.js"></script>
<script type="text/javascript" src="../func/js/FACD-V20.js"></script>
<script type="text/javascript" src="../func/js/FVCF-V20.js"></script>
<script type="text/javascript" src="../func/js/formularios.js"></script>
<script type="text/javascript" src="../func/js/mensajes.js"></script>
<script type="text/javascript" src="../func/js/validaciones.js"></script>
<script src="../func/js/sweetalert.min.js"></script>
</head>
<script type="text/javascript">
	function guardarUsuario(){
		swal("Registro exitoso.");
		var donde = $("#donde").val();
		//archivo
		var filevalue=document.getElementById("file").value;
		var description=document.getElementById("description").value;
		if (donde=="modificar") {
			if(filevalue=="" || filevalue.length<1){
			}
			else{
				$("#usum_foto_vali").val("S");
      	var extension = $("#file").val().split('.').pop(); // Obtengo la extensión
				if(extension == "png" ){
				}
				else{
 			   	swal('Problemas al cargar el archivo, el formato debe ser png');
					return false;
				}
			}	
		}
		else{
			if(filevalue=="" || filevalue.length<1){
				$("#usum_foto_vali").val("N");
			}
			else{
				$("#usum_foto_vali").val("S");
				var extension = $("#file").val().split('.').pop(); // Obtengo la extensión
					if(extension == "png" ){
					}
					else{
	 			   	swal('Problemas al cargar el archivo, el formato debe ser png');
						return false;
					}
			}
		}
		//archivo
		var usum_idxx = $("#usum_idxx").val();
		var accion = (donde=="modificar" ? "guar_modi_usua" : "guardarUsuario");
		var usum_iden = $("#usum_iden").val().replace(/\./g,'').replace(/\,/g,'');
		var usum_nomb = $("#usum_nomb").val();
		var usum_apel = $("#usum_apel").val();
		var usum_dire = $("#usum_dire").val(); 
		var usum_emai = $("#usum_emai").val();
		var usum_tele = $("#usum_tele").val();
		var usum_movi = $("#usum_movi").val();
		var usum_idpe = $("#usum_idpe").val();
		var usum_pass = $("#usum_pass").val();
		var usum_pas2 = $("#usum_pas2").val();
		$("#usum_idpe_hidden").val(usum_idpe);
		$("#usum_iden").val(usum_iden);

		
		var atributos_validar = ["#usum_iden","#usum_nomb","#usum_apel","#usum_dire","#usum_idde","#usum_tele","#usum_movi","#usum_idpe"];
		var resul_validar = validarAtributos(atributos_validar);
		if (resul_validar == "si") {
					return false;
		}

		if (donde!="modificar") {
			var atributos_validar = ["#usum_pass"];
			var resul_validar = validarAtributos(atributos_validar);
			if (resul_validar == "si") {
						return false;
			}
		}

		var resul_validar="no";
		if (usum_emai != "" ) {
			resul_validar = validarEmail(usum_emai,"#usum_emai");
			if (resul_validar == "si") {
				return false;
			}
		} 
		
		if (usum_pass!="") {
			if (usum_pass!=usum_pas2) {
				swal("La contraseña no coincide ");
				return false;
			}
		}
		var size = document.getElementById('file').files[0].size;
		if (size >= 2000000) {
			swal("La imagen es demasiado pesada. Debe ser menor de 2 gigabytes.");
			return false;
		}
		return true;
	}

	function limpiarFormulario(){
		/*$("#usum_pass").val("");
		$("#usum_fevi").val("");*/
		//alert("hla");
	}



	//verificar la cedula ingresadda
	function verificar_cedula(usum_idxx){
		var accion = "verificar_cedula";
		var cedula = $("#usum_iden").val().replace(/\./g,'');
		$.ajax({
			type :"POST",
			url : "../func/php/FUUSUA_MAES-V10.php",
			data : {
				accion : accion,
				cedula : cedula,
				usum_idxx : usum_idxx
			},
			success:function(data) {
				//swal(data);
				if (data=="cedu_repe") {
					swal("Esta cédula ya se encuentra almacenada");
					$("#usum_iden").val("");
					$("#usum_iden").focus();
				}
				if (data=="cedu_inactiva") {
					swal({
						title: "Activar usuario",
						text: "Este usuario ya se encuentra almacenado ¿desea activarlo?",
						showCancelButton: true,
						confirmButtonColor: "#DD6B55",
						confirmButtonText: "Activar",
						closeOnConfirm: false
					}).then(function(){
						var accion = "activarUsua";
						$.ajax({
							type :"POST",
							url : "../func/php/FUUSUA_MAES-V10.php",
							data : "accion="+accion+"&cedula="+cedula,
							success:function(data) {
								swal({
									title: "",
									text: "Usuario activado con éxito",
									type: "success",
									timer: 3000,
									showConfirmButton: false
								});
								mostrarFornulario();
							}
						});
					}, function (dismiss) {
				  // dismiss can be 'cancel', 'overlay',
				  // 'close', and 'timer'
				  if (dismiss === 'cancel') {
					$("#usum_iden").val("");
					$("#usum_iden").focus();
				  }
				  });
				}
			}
		});
	}

	// agregar nuevo usuario
	function nuevoUsuario(){
		var accion = "nuevoUsuario";
		$.ajax({
			type :"POST",
			url : "../func/php/FUUSUA_MAES-V10.php",
			data : {
			accion : accion},
			success:function(data) {
				$("#container").html(data);
				$("#usum_iden").focus();
			}
		});
	}
	
	// Busqueda avanzada de Usuario
	function busc_aban_usum(){
		var accion = "busc_aban_usum";
		var buscar_usum = $("#buscar_usum").val();
		$.ajax({
			type :"POST",
			url : "../func/php/FUUSUA_MAES-V10.php",
			data : {
				accion : accion,
			buscar_usum : buscar_usum},
			success:function(data){
				$("#container").html(data);
			}
		});
	}
	
	// MOSTRAR FORMULARIO
	function paginarHabilidades(){
		var accion = "paginarHabilidades";
		$.ajax({
			type :"POST",
			url : "../func/php/FUUSUA_MAES-V10.php",
			data : {
			accion : accion},
			success:function(data){
				$("#container3").html(data);
			}
		});
	}

	// MOSTRAR FORMULARIO
	function mostrarFornulario(){
		var accion = "mostrarFornulario";
		$.ajax({
			type :"POST",
			url : "../func/php/FUUSUA_MAES-V10.php",
			data : {
			accion : accion},
			success:function(data){
				$("#container").html(data);
			}
		});
	}
	
	// INACTIVAR USUARIO
	function eliminarUsuario(usum_idxx){
		swal({
			title: "Eliminar Usuario",
			text: "¿Esta seguro de eliminarlo?",
			showCancelButton: true,
			confirmButtonColor: "#DD6B55",
			confirmButtonText: "Eliminar",
			closeOnConfirm: false
		}).then(
		function(){
			var accion = "eliminarUsuario";
			$.ajax({
				type :"POST",
				url : "../func/php/FUUSUA_MAES-V10.php",
				data : {
				accion : accion,
				usum_idxx : usum_idxx},
				success:function(data) {
					swal({
						title: "",
						text: "Usuario eliminado con exito",
						type: "success",
						timer: 3000,
						showConfirmButton: false
					});
					mostrarFornulario();
				}
			});
		});
	}
	 
	//modificar usuario
	function modificarUsuario(usum_idxx){
		var accion = "modificarUsuario";
		$.ajax({
			type :"POST",
			url : "../func/php/FUUSUA_MAES-V10.php",
			data : {
				accion : accion,
			usum_idxx : usum_idxx},
			success:function(data){
				$("#container").html(data);
				$("#usum_iden").focus();
			}
		});
	}

	//cambiar check box con el label
	function labe_chek(esta){
		if (esta=="act") {
			$('#usum_esta_ina').attr('checked', false); 
			$('#usum_esta_act').attr('checked', true); 
			$("#resul_usum_esta").val("ACT");
		}
		else{
			$('#usum_esta_act').attr('checked', false);
			$('#usum_esta_ina').attr('checked', true); 
			$("#resul_usum_esta").val("INA");
		}
	}
	
	//deschekear
	function radi_chek(esta){
		if (esta=="act") {
			$('#usum_esta_ina').attr('checked', false); 
			$("#resul_usum_esta").val("ACT");
		}
		else{
			$('#usum_esta_act').attr('checked', false);
			$("#resul_usum_esta").val("INA");
		}
	}
	
	// paginador
	function cambiarPaginaUsuar(pagina){
		var accion = "cambiarPaginaUsuar";
		$.ajax({
			type :"POST",
			url : "../func/php/FUUSUA_MAES-V10.php",
			data : {
				accion : accion,
			pagina : pagina},
			success:function(data){
				$("#container").html(data);
			}
		});
	}

	// usua
	function limp_nuev_usua(){
		$("#usum_iden").val("");
		$("#usum_nomb").val("");
		$("#usum_apel").val("");
		$("#usum_dire").val(""); 
		$("#usum_tele").val("");
		$("#usum_movi").val("");
		$("#usum_emai").val("");
		$("#usum_pass").val("");
		$("#usum_pas2").val("");
		$("#usum_prof").val("");
		$("#usum_idde").val("");
		//document.getElementById("formulari").reset();
		$("#usum_iden").focus();
	}

	// HAVILIDADES
		//validarCheckHabilidades
		function validarCheckHabilidades(usum_idxx){
			if (document.getElementById('check'+usum_idxx).checked) {
				document.getElementById("3radioHavilidad"+usum_idxx).checked = true;
			} 
			else {
				document.getElementById("1radioHavilidad"+usum_idxx).checked = false;
				document.getElementById("2radioHavilidad"+usum_idxx).checked = false;
				document.getElementById("3radioHavilidad"+usum_idxx).checked = false;
				document.getElementById("4radioHavilidad"+usum_idxx).checked = false;
				document.getElementById("5radioHavilidad"+usum_idxx).checked = false;
			}
		}

		//validarRadioHavilidades
		function validarRadioHavilidades(usum_idxx,cualRadio){
			if (document.getElementById('check'+usum_idxx).checked) {
				//document.getElementById("3radioHavilidad"+usum_idxx).checked = true;
			} else {
				document.getElementById(cualRadio+"radioHavilidad"+usum_idxx).checked = false;
			}
		}  

		//resultado
		function tresult(){
			var cantRegistrosHabilidades = $("#cantRegistrosHabilidades").val();
			var check =0;
			var radio = 0;
			var vectorIdxMatris = "";
			var vectorradio = "";
			for (var i = 1; i <= cantRegistrosHabilidades-1; i++) {
				radio = parseInt($('input:radio[name=radioHavilidad'+i+']:checked').val());
				if (document.getElementById('check'+i).checked) {
				
					if (check == 0) {
						check = check + radio; 
						vectorIdxMatris = document.getElementById('check'+i).value;
						vectorradio += radio;
					}
					else{
						check = check + radio; 
						vectorIdxMatris += ","+document.getElementById('check'+i).value;
						vectorradio += ","+radio;
					}
				}
			}
			//salert(vectorradio);
			$("#vectorIdxMatris").val(vectorIdxMatris);
			$("#vectorradio").val(vectorradio);
		}
	// HAVILIDADES
</script>
<body onload="mostrarFornulario();cargarMenu();">
	<div id="wrapper">
		<div class="overlay"></div>
		<!-- Sidebar -->
		<nav  class="navbar navbar-inverse navbar-fixed-top" id="sidebar-wrapper" role="navigation"><?php include 'FRMENU-V10.php';?></nav>
		<!-- /#sidebar-wrapper -->
		<div id="page-content-wrapper">
			<button type="button" class="hamburger is-closed" data-toggle="offcanvas">
				<span class="hamb-top"></span>
				<span class="hamb-middle"></span>
				<span class="hamb-bottom"></span>
			</button>
			<div id="pagewrap">
				<div id="header">
					<div class="logo"><img src="../imag/logo2.png" height="140px"></div>
				</div>
				<center>
					<div class ="titulo">USUARIOS</div>
				</center>
			</div>
			<div id="content">
				<center>
					<div id="container"></div>
				</center>
			</div>
			<div id="footer" class="col-md-12">
				<center>
					<img height="50px" width="100%" src="../imag/ft_2.png">
          <br><a href="http://www.innovesting.com.co" id="links">Innovesting S.A.S.</a>
				</center>
			</div>
			<div id="div_fotos"></div>
		</div>
	</div>
</div>
</body>
</html>